//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//



@interface NSManagedObject (DeleteEntities)

+ (void) deleteAllObjects: (NSString *) entityDescription;

@end
