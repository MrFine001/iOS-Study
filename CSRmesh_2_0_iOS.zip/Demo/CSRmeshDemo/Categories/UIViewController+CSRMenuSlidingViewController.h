//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CSRMenuSlidingViewController.h"

@interface UIViewController (CSRMenuSlidingViewController)

- (CSRMenuSlidingViewController*)slidingViewController;

@end
