//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//


#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CSRMenuSlidingSegue : UIStoryboardSegue

@property (nonatomic, assign) BOOL skipSettingTopViewController;

@end
