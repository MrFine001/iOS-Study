//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//

#import <UIKit/UIKit.h>

extern NSString * const CSRMenuActionTableViewCellIdentifier;

@interface CSRMenuActionTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *actionNameLabel;

@end
