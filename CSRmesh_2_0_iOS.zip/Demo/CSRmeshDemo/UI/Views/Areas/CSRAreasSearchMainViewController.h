//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//

#import <UIKit/UIKit.h>

@interface CSRAreasSearchMainViewController : UITableViewController

@property (nonatomic) NSMutableArray *filteredAreasArray;

@end
