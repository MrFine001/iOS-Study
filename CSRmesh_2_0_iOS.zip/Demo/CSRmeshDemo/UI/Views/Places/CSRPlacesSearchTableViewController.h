//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//

#import <UIKit/UIKit.h>

@interface CSRPlacesSearchTableViewController : UITableViewController

@property (nonatomic) NSMutableArray *filteredPlacesArray;

@end
