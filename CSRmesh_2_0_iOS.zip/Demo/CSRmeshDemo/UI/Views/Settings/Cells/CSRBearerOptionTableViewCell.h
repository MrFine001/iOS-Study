//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//

#import <UIKit/UIKit.h>

extern NSString * const CSRBearerOptionCellIdentifier;

@interface CSRBearerOptionTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *bearerNameLabel;

@end
