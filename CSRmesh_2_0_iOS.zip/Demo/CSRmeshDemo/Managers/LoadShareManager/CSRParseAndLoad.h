//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//



#import <Foundation/Foundation.h>

@interface CSRParseAndLoad : NSObject


- (void) parseAndLoadDevices:(NSArray *)devicesArray;
- (void) parseAndLoadGroups:(NSArray *)devicesArray;

@end
