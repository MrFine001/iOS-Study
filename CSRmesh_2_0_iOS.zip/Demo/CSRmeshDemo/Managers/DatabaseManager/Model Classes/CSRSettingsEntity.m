//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//

#import "CSRSettingsEntity.h"
#import "CSRPlaceEntity.h"


@implementation CSRSettingsEntity

@dynamic cloudMeshID;
@dynamic cloudTenancyID;
@dynamic concurrentConnections;
@dynamic listeningMode;
@dynamic retryCount;
@dynamic retryInterval;
@dynamic siteID;
@dynamic userID;
@dynamic place;

@end
