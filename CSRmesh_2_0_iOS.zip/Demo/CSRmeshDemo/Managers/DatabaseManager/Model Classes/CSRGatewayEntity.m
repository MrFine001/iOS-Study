//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//

#import "CSRGatewayEntity.h"


@implementation CSRGatewayEntity

@dynamic basePath;
@dynamic host;
@dynamic name;
@dynamic port;
@dynamic uuid;
@dynamic deviceId;
@dynamic state;

@end
