//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//

#import "CSRUserEntity.h"
#import "CSRPlaceEntity.h"


@implementation CSRUserEntity

@dynamic email;
@dynamic name;
@dynamic token;
@dynamic userId;
@dynamic places;

@end
