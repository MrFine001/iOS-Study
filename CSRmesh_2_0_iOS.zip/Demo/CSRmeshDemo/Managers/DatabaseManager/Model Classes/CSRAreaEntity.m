//
// Copyright 2015 Qualcomm Technologies International, Ltd.
//

#import "CSRAreaEntity.h"
#import "CSRDeviceEntity.h"


@implementation CSRAreaEntity

@dynamic areaID;
@dynamic areaName;
@dynamic favourite;
@dynamic devices;

@end
